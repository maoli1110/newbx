'use strict';

// 注册核心模块
ApplicationConfiguration.registerModule('home');